const nodemailer = require("nodemailer");
const fs =require('fs')

const mailer={}

mailer.send=function send(destinatario,plantilla){
    
  let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'proyectoana@gmail.com', 
      pass: 'Fullstack#01', 
    },
  });
  mailer.getPlantilla(plantilla)
  .then (datos=>
  transporter.sendMail({
    from: '"Lavanderia Rapidin " <lavanderiaRPD@gmail.com>', 
    to: destinatario, 
    subject: "Lavanderia Rapidin - Datos de tu reserva", 
    text: "Datos de tu cita:", 
    html: datos.replace('{{nombre}}' , destinatario)
  })
  )
}

mailer.getPlantilla= async function getPlantilla(plantilla){
        return fs.readFileSync('./modules/mailer-plantilla/' + plantilla + '.html', 'utf8')
}

module.exports=mailer
