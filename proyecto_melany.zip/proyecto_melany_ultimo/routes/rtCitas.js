const express = require ('express')
const rtCitas = express.Router()
const fs =require('fs')
const daoCitas = require ('../dao/daoCitas')
const Cita=require('../models/Cita')
const mailer= require('../modules/mailer')


rtCitas.get('/nueva',(req,res)=>{
    res.render('home')
})
rtCitas.get('/modificar', (req,res)=>{
    res.render('modificar')
})
rtCitas.get ('/cancelar', (req,res)=>{
 res.render('cancelar')
})
rtCitas.post('/cancelar',(req,res)=>{
    // let idUsuario=cita.cId
     let cId=req.body
     console.log(cId)
    if(cId==cId){
        daoCitas.cancel(cId)
        .then(res.render('respuestacancelacion'))
    }else { 
            res.render('home')
        }
    }
)
rtCitas.get('/respuestacancelacion',(req, res)=>{
    res.render('respuestacancelacion')
})
rtCitas.get('/citamodificada',(req, res)=>{
    res.render('citamodificada')
})
//guardar cita 
rtCitas.post('/procesar',(req,res)=>{
    let nuevaCita=new Cita (req.body)
    let errores=nuevaCita.validar()
    if(errores.length==0){
        daoCitas.save(nuevaCita)
        .then(cita=>{
            if(cita==null)//esta ocupada
            res.render('error')
            else{
                //enviar un email
                mailer.send()
                res.render('respuesta',{cita:cita})
            }
        })   
    }else{
        res.render('home', {
            errores:errores, 
            cita:nuevaCita})
        }
})
module.exports=rtCitas